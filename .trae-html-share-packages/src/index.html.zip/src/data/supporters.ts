export const supporters = `ken burgan
Sera's Nafitlaan
Richard Rogers
Hylobate
Colin deSousa
Aurelia De La Silla
Maciej Kontny
Ricky L Cain
Iggyflare
Garrett Renner
Michael Harris
Joshua Maly
Nigel Guest
Theo Hodges
BERTHEAS Frédéric
lilMoni
Δημήτρης Μάρκογιαννακης
Lee S.
Chris Dibbs
jarrad tait
Jacen Solo
Hannes Rotestam
Preston Hicks
Лонгин
Will Fink
ControlFreq
IllAngel
John Giardina
Thiago Prado
Zhang Dijon
NoBurny
thibault tersinet
scarletsky 
Nich Smith
Omegus
Karl Abrahamsson
Sara Fernandes
peetey897
Cooper Janse
G F
Glen Aultman-Bettridge
Nathan Rogers
Benjamin Mock
CadmiumMan 
Kirk Edwards
Leigh G
Thom Colyer
Frederik
C pstj
Zachary Pecora
Trevor D'Arcey
Ryan Gauvin
Shawn Moore
Jim Channon
Kyarou
Actual_Dio
Jim B Johnson
Robert Rinne
Zion 
Kenji Yamada
DerWolf 
RLKZ1022
Neyimadd
Aaron Blair
Mira Cyr
Bird Law Expert
S A Rudy
Sam Spoerle
angel carrillo
Alden Z
Holly Loveless
Sea Wolf
Atenfox 
Cyberate
E. Jason Davis
Caro Lyns
David Kaul
Charlotte Wiland
Kyle Barrett
Ian Grau-Fay
cameron cannon
RedSpaz
John Wick
Randy Ross
Rita
Ele
Johnathan Xavier Hutchinson
Andrew Stein
Ghettov Milan
Malke
TameMoon
Daniel Cooper
Markus Peham
The Next Level
Alexander Whittaker
Sidr Dim
William Markus
Jordan
Pleaseworkforonce 
Damon Gallaty
Trentin Bergeron
Emarandzeb
Laulajatar
Dale McBane
Chris Kohut
Preston Mitchell
Andrew Kircher
Frank Fewkes
Moist mongol
Joshua Xiong
Jan Bundesmann
www15o
Game Master Pro
jason baldrick
Exp1nt
w 
Shubham Jakhotiya
Braxton Istace
LesterThePossum
Rurikid
ojacid .
james 
A Patreon of the Ahts
BigE0021
Angelique Badger
Jonathan Williams
AntiBlock 
Redsauz
Florian Kelber
John Patrick Callahan Jr
Alexandra Vesey
Bas Kroot
Dzmitry Malyshau
PedanticSteve
Josh Wren
BLRageQuit
Dario Spadavecchia
Neutrix 
Markell
Rocky
Robert Landry
Skylar Mangum-Turner
Nick Mowry
Anjen Pai
Hope You're Well
Alexandre Boivin
Racussa
Mike Conley
Karen Blythe
Mark Sprietsma
Xavier privé
Tommy Mayfield
Václav Švec
Binks
Mackenzie 
Linn Browning
Writer's Consultant Page by George J.Lekkas
Andrew Hines
Wexxler 
Jason Matthew Wuerfel
Milo Cohen
Alan Buehne
Dominick Ormsby
Espen Sæverud
Rasmus Legêne
rbbalderama
Nobody679
Prince of Morgoth
Jaryd Armstrong
Gary Smith
ThyHolyDevil
良义 金
Andrew Pirkola
Dig
Chris Gray
Tyshaun Wise
Phoenix
Ethan Cook
Jordan Bellah
Petro Lombaard
Kass Frisson
Lazer Elf
Gavin Madrigal
Rox
PinkEvil
Martin Lorber
Emanuel Pietri
Alex Beard
Jeffrey Henning
Eric Alexander Cartaya
Dust Bunny
GameNight 
Beingus
Crys Cain
Lon Varnadore
Thomas Mortensen Hansen
Drinarius
Ed Wright
Adrian Wright
Zklaus 
Chris Bloom
PlayByMail.Net
Maxim Lowe
Aquelion
Tiber
Daydream1013
Page One Project
Clonetone
Egoensis 
Brad Wardell
Heaven N Lee
BarnabyJones
Paul Ingram
Lance Saba
Chad Riley
Austin
Rowland Kingman
Decimus Vitalis
Grayson McClead
Battleturtle1
Kristin Chernoff
Justin Mcclain
Patrick Jones
Esther Busch
Chance Mena
JimmyTheBob
Antiroo 
Dalton Clark
Guilherme Aguiar
Simon Drapeau
Akirsop
Radovan Zapletal
Vanessa Anjos
Rikard Wolff
Justa Badge
teco 47
Jake
Miguel Alejandro
Blargh Blarghmoomoo
Jakob Siegel
Grant A. Murray
Jarno Hallikainen
Jan Ka
Joshua Vaught
MaxOliver 
WarWizardGames
Evan-DiLeo 
Eric Moore
Kyle S
Alex Debus
Uniquenameosaurus 
Dean Dunakin
Jack 
Bryan Brake
McNeil Atticus Inksmudge
Char 
Tom Van Orden jr
Kendall Patterson
Akylos 
Barna Csíkos
Nicholas Grabstas
OldFarkas
Riley Seaman
Daniel Gill
Kyle Robertson
Natasha Taylor
Pierrick Bertrand
Jared.K
Dylan Devenny
logic_error
SashaTK
Steve Johnson
MontyBoosh 
Achillain 
Jaden 
Vito Martono
Thirty-OneR 
Eric Foley
ThatGuyGW 
Dee Chiu
James H. Anthony
Kevin Cossutta
MadNomadMedia
Darinius Dragonclaw Studios
Tsahyla (Triston Lightyear)
Christopher Whitney
María Martín López
Annie Rishor
Aram Sabatés
Jeppe Skov Jensen
Martin Seeger
Oneiris (Oni)
EternalDeiwos
Richard Keating
StroboWolf 
Rick Falkvinge
Zewen Senpai
Adam Butler
Kassidy 
Sadie Blackthorne
ErrorForever 
Seth Fusion
Gus 
Paul 
Lucid 
Allen Varney
Hannah May
Sankroh
Eliot Miller
Detocroix 
Meg Ziegler
rob bee
Anoplexian 
Marten F
Erin D. Smale
Johnpaul Morrow
Roekai 
Drunken_Legends 
Jesse Holmes
Maxwell Hill
Jan Dvořák
SirTobit 
G0atfather
Allen S. Rout
Pippa Mitchell
Austin Miller
Caner Oleas Pekgönenç
Alison Bull Bear
Bradley Edwards
Tertiary 
Daniel
Joshua E Goodwin
Shaun Alexander
Ryan Lege
Myrrhlin
Jesper Cockx
Noirbard 
Dice
Brian Drennen
Giant Monster Games
Reya C.
Krk
Endwords 
Jacob Harrington
RK
Michael Greiner
Steven Bennett
Brice Moss
Whakomatic x
Stephen Herron
kosmobius
ZizRenanim
Barished 
Maur Razimtheth
Aaron bateson
Diklyquill
Shawn Taylor
Brady R Rathbun
FlippantFeline 
Shadow
J 
Tamashi Toh
Huw Williams
Graves
ShadeByTheSea
The Dungeon Masters
Valerie Elise
Empi3
William Pucs
Michael Carmody
Marco Veldman
naikibens220
Jordon Phillips
_gfx_ 
F. Casanova
Jared McDaris
BlastWind 
Taldonix
Connor McMartin
Nexoness 
Guy 
Maggie 
AdvancedAzrielAngel
Alfred García
Norbert Žigmund
Jennifer
Titanium Tomes
John Ackley
Invad3r233
Jonathan Killstring
Jessica Thomas
Nikita Kondratjuks
Steve Hyatt
PoliticsBuff 
Ian arless
Karnat 
Hilton Williams
Kevin 
Katharina Haase
Hisham Bedri
Bird
JOSHUA QUALTIERI
Preston Brooks
Troy Schuler
DerGeisterbär 
L. V. Werneck
Marcus Hellyrr
yami
Daniel Eric Crosby
Augusto Chiarle
Doug Churchman
David Roza
Alexander Thomas
Ashley Wilson-Savoury
Nathan L Myers
Theresa Walsh
JP Roberts III
William Henry
OldbeanOldboy
Javasharp
Diagonath 
Gun Metal Games
Scott Marner
Alloyed Clavicle
Valerii Matskevych
Spencer Sherman
Nolan Moore
James Schellenger
Pat 
Dino Princip
Shawn Spencer
Timothée CALLET
KC138
Nylian 
Kate 
Markus Finster
CanadianGold 
AstralJacks 
Keith Marshall
Scott Davis
Joseph Miranda
Shaptarshi Joarder
Branndon
EP
Johan Fröberg
Sasquatch 
Chase Mayers
Sizz_TV 
Ryan Westcott
Nathan Mitchell
Curt Flood
Mikey 
E.M. White
Billy 
Vlad Tomash
Xariun
Luke Nelson
W Maxwell Cassity-Guilliom
Marty H
Aaron Meyer
Max Amillios
chris 
cyninge 
Omegavoid 
Fritjof Olsson
Crazypedia 
Duncan Thomson
William Merriott
Gold Tamarin
Lhoris 
Jonathan
Jon
Massimo Vella
Feuver 
aymeric 
Eric Schumann
Rei 
Fondue 
Paavi1
Wil Sisney
David Patterson
L
Justin Scheffers
Commieboo
Garrison Wood
Emsiron
Frosty
John Joseph Adams
The_Lone_Wanderer
Andrew Stein
Groonfish
soup
Bruno Haack Vilar
Ian Burke
Tentacle Shogun
Andrew Chandler
Fritz Wulfram
Doom Chupacabra
Zakharov
Dylan Fox
Alfred Piccioni
Avery Vreeland
Kennedy
Zack Wolf
Matjam
Jeff Johnston
Hunter Hawthorne
Sunsette 
Travis Love
Dakian Delomast
Kyle
Davis Walker
Naomi
Clément D
Jake Herr
ReV0LT
Jack Dawson
Queso y Libertad
RadioJay21H
NEO
Crecs
A AASD
Mikhail Ushakov
NoFun
AmbiguousCake
Madeline Naiman
2FingerzDown
Josiah Lulf
Vector Tragedy
yann
Blarghle Hargle
Jelke Boonstra
afistupmabum
Rob Frantz
Driver
Tr4v3l3r
Cooper Cantrell
Maximilien Bouillot
J.E. Ellis
Igor
John Todd
burning.rosary
Shane Roppel
Hank Agrippa
Noah Morris
Phil Karecki
Matthew Jarocki
Lucius Licinius Lucullus
Andrew Haney
Noah Morris
Phil Karecki
Matthew Jarocki
Lucius Licinius Lucullus
Andrew Haney
Jesse Luke
Lord_Luce
Neko no Maigo
Hossyboy 
Yasui Masatake
Jesse Roy
Remain
Douglas Rector
J Clark
Raine Logan
Matty Ice
DieMuetze
Dan Popoli
Marwyn
Kederalia
Whyse Wytch
Elliyevee
James Miller
Pirate Fish
David Leitner
Vyritecht
emre
Don't mail me
Isaac Wooten
MisterPete
Johanna Martin
Marmalade_MacGuffin
James Benware
FortunesFaded
breadsticks
Murderbits
Ben Jones
Marco Faltracco
L
silentArtifact
Keith Potter
Morgan Gilbert
Alengork Gamer
Don Johnson
Mish
effervescent
Trevor Sansom
Eric Christian Berg
Jamin
Aurelia De La Sella
morgan
Barry Gill
Wolf
Titan_650
Sebastian Tampu
dr_not_sam
Mie96
Riley
Amber Davis
tomtom1969vlbg
Eric Knight
Adeline Lefizelier
Jerry Palmer
Colin Lewis
ｌうｃｙ
Peyton
Silvershade
jim8333
Kevin
Jeffrey Brown
Tyler Riggs
Justin Warrington
Sovrynth Systems
Coffee
Justin
Paul Facknitz
William Fichou
Morphine
ussis6nad
Ælyndor
Patrick McEntee
y John
Sean O'Daniels
ShadowMole
FlightlessDutchman
Gawain Yeo
Tom Hollingworth
Scott Gunn
Gabe Hurd
Benjamin Sardinsky
Task_Failer`;

window.Supporters = supporters;

export const trbackers = `匿名1
匿名2
行
爱发电用户_8a1a9
匿名3
匿名4
匿名5
匿名6
匿名7
susu_WHAT
firecracker
咳哎
爱发电用户_66f75
青莲剑歌
爱发电用户_eWFG
了望的猪猪
朱■哲
师维梵
JUNJUN
爱发电用户_YTSe
怎么回事
Yotta
爱发电用户_850dc
飞天归来
神经漫游者nobu
爱发电用户_HEeR
匿名8
DCVSMarvel
■兵
米卡柳丁
路旁的菜叶
爱之梦
居高声自远
小光
Crisp
匿名9
■越
匿名10
星空下的牧草
匿名11
■■晗
长江长
匿名12
wx
匿名13
匿名14
及其他七个好心人`;

// temp legacy compatibility（与原版 window.Supporters 模式一致）
window.trbackers = trbackers;

declare global {
  interface Window {
    Supporters: typeof supporters;
    trbackers: string;
  }
}
